from django.shortcuts import render
# Create your views here.

def home(request):
    return render(request,'home.html');

def about(request):
    return render(request, 'info.html');

def registration(request):
    return render(request, 'registration.html');

def authorization(request):
    return render(request, 'authorization.html');

def viewDataBase(request):
    return render(request, 'viewDataBase.html');
